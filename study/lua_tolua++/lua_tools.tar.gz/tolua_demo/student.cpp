#include "student.h"


Student::Student()
{
}

void Student::Run()
{
	cout << "Student Run" << endl;
}

void Student::Run(int a)
{
	cout << "Student Run" << a << endl;
}

Student::~Student()
{
}

