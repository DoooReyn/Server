#ifndef __STUDENT_H__
#define __STUDENT_H__

#include<iostream>
using namespace std;

class Student
{
public:
	Student();
	~Student();

	void Run();

	void Run(int a);
};


#endif
